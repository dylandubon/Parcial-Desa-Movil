export 'package:movie/screens/detail_screen.dart';
export 'package:movie/screens/home_screen.dart';